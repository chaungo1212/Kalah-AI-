To run the game locally with an AI:

* Compile Game.java
* Run Game




To run the game server-client style between a human and AI:

* Open two instances, one for server, one for client
* Compile ServerGame.java
* Run ServerGame
* Compile ClientGame.java
* Run ClientGame in new instance



To run the server-client with no game play:

* Open two instances, one for server, one for client
* Compile FinalServer.java
* Run FinalServer
* Compile FinalClient.java
* Run FinalClient.java